# Panduan Toko Mandiri

## Isi folder
- `index.html` : tampilan toko (tidak perlu diubah)
- `produk.js`  : daftar produk, nama toko, slogan, nomor WhatsApp (satu-satunya file yang Anda edit)
- `foto/`      : tempat semua foto produk

## Cara menambah produk
1. Simpan foto produk ke folder `foto/` (misalnya `scr-001.jpg`). Disarankan berukuran di bawah 300 KB.
2. Buka `produk.js` dengan Notepad atau editor teks.
3. Salin satu blok produk di dalam `window.PRODUK = [ ... ]`, lalu isi:
   kode, nama, harga (angka saja, tanpa titik), link produk (diawali https://), dan foto.
4. Setiap blok dipisah koma. Simpan file.
5. Unggah ulang folder ke hosting (lihat di bawah).

Contoh dua produk:

    window.PRODUK = [
      { kode: "SCR-001", nama: "Nama Produk A", harga: 30000, link: "https://shopee.co.id/...", foto: "foto/scr-001.jpg" },
      { kode: "SCR-002", nama: "Nama Produk B", harga: 85000, link: "https://shopee.co.id/...", foto: "foto/scr-002.jpg" }
    ];

Tips: jika toko tiba-tiba kosong, biasanya ada koma atau kurung yang kurang di `produk.js`.

## Opsi A: Netlify (paling mudah)
1. Masuk ke akun Netlify Anda, buka situs yang ingin diperbarui (atau buat situs baru).
2. Cari bagian **Deploys**, lalu seret (drag and drop) seluruh folder `toko-mandiri` ke area unggah.
3. Tunggu selesai. Alamat situs Anda langsung memuat versi terbaru.
Setiap kali ada produk baru, ulangi langkah 2 dengan folder yang sudah diperbarui.

## Opsi B: GitHub Pages
1. Buat repositori baru di GitHub, lalu unggah semua isi folder ini (index.html, produk.js, folder foto).
2. Buka **Settings > Pages**, pilih branch `main` dan folder `/ (root)`, lalu simpan.
3. Tunggu beberapa menit. Alamat situs akan tampil di halaman yang sama.
Untuk memperbarui produk, edit `produk.js` langsung di GitHub (ikon pensil), lalu klik Commit. Foto baru ditambah lewat **Add file > Upload files**.

## Keamanan
Pembeli hanya bisa melihat toko. Yang bisa mengubahnya hanya orang yang memegang akun Netlify atau GitHub Anda, jadi gunakan password kuat dan aktifkan verifikasi dua langkah.
